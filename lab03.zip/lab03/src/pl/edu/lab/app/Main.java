package pl.edu.lab.app;

import pl.edu.lab.model.Category;
import pl.edu.lab.model.Product;
import pl.edu.lab.service.ProductService;
import pl.edu.lab.util.Logger;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Logger logger = new Logger();
        ProductService productService = new ProductService();

        Category electronics = new Category("Elektronika");
        Category food = new Category("Spożywcze");

        Product p1 = new Product("Laptop", 3500.00, electronics);
        Product p2 = new Product("Chleb", 4.50, food);
        Product p3 = new Product("Smartfon", 2000.00, electronics);
        Product p4 = new Product("Zapiekanka", 25.00, food);

        productService.addProduct(p1);
        productService.addProduct(p2);
        productService.addProduct(p3);
        productService.addProduct(p4);

        logger.info("Lista wszystkich dostępnych produktów:");
        List<Product> products = productService.getAllProducts();

        for (Product product : products) {
            logger.info(product.toString());
        }
    }
}