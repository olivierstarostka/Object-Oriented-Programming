package pl.edu.lab.util;

public class Logger {
    public void info(String message) {
        System.out.println("[INFO] " + message);
    }
}