## I. Dokumentacja do lab. nr 3 - "Modułowość pakiety i importy"
## II. Olivier Starostka - grupa 4, semestr III
## III. Przedmiot - "Programowanie obiektowe"

## IV. Opis zadania do realizacji
Do zrealizowania były następujące zadania:  
  - Utwórz strukturę pakietów pl.edu.lab.model, pl.edu.lab.service, pl.edu.lab.app i przenieś klasy do odpowiednich pakietów.
  - Zaimplementuj klasę Product w pakiecie model oraz klasę ProductService w pakiecie service, która operuje na liście produktów.
  - W klasie Main (pakiet app) użyj importów jawnych i uruchom scenariusz dodawania oraz wypisywania produktów.
  - Pokaż różnicę między import java.util.List; a import java.util.*; i opisz, które podejście preferujesz w projekcie i dlaczego.
  - Rozdziel projekt na co najmniej 5 klas tak, aby każda miała jedną odpowiedzialność i była w logicznym pakiecie.
  - Dodaj krótką instrukcję uruchomienia projektu z pakietami (kompilacja i uruchomienie klasy głównej) w formie 4-6 punktów.

## V. Technologie wykorzystane w zadaniu
  - Java

## VI. Realizacja zadania
<br>

### 1. Kod Javy
#### Zad. 1
![ukazanie zad 1](zad1.png)

#### Zad. 2
src/pl/edu/lab/model/Category.java
```java
package pl.edu.lab.model;

public class Category {
    private String name;

    public Category(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
```

src/pl/edu/lab/model/Product.java
```java
package pl.edu.lab.model;

public class Product {
    private String name;
    private double price;
    private Category category;

    public Product(String name, double price, Category category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public Category getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "Produkt: " + name + " | Cena: " + price + " | Kategoria: " + category.getName();
    }
}
```

src/pl/edu/lab/service/ProductService
```java
package pl.edu.lab.service;

import pl.edu.lab.model.Product;
import java.util.ArrayList;
import java.util.List;

public class ProductService {
    private List<Product> products;

    public ProductService() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public List<Product> getAllProducts() {
        return products;
    }
}
```

#### Zad. 3
src/pl/edu/lab/app/Main.java
```java
package pl.edu.lab.app;

import pl.edu.lab.model.Category;
import pl.edu.lab.model.Product;
import pl.edu.lab.service.ProductService;
import pl.edu.lab.util.Logger;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Logger logger = new Logger();
        ProductService productService = new ProductService();

        Category electronics = new Category("Elektronika");
        Category food = new Category("Spożywcze");

        Product p1 = new Product("Laptop", 3500.00, electronics);
        Product p2 = new Product("Chleb", 4.50, food);
        Product p3 = new Product("Smartfon", 2000.00, electronics);
        Product p4 = new Product("Zapiekanka", 25.00, food);

        productService.addProduct(p1);
        productService.addProduct(p2);
        productService.addProduct(p3);
        productService.addProduct(p4);

        logger.info("Lista wszystkich dostępnych produktów:");
        List<Product> products = productService.getAllProducts();

        for (Product product : products) {
            logger.info(product.toString());
        }
    }
}
```

#### Zad. 4
Nie było potrzeby zaimportowania wildcardow, wystarczył import 1 klasy.

#### Zad. 5
```java
package pl.edu.lab.util;

public class Logger {
    public void info(String message) {
        System.out.println("[INFO] " + message);
    }
}
```

#### 2. Zrzuty ekranu pokazujące wynik działania aplikacji/skryptu:  
![pokazanie działania projektu](pokazanie-projektu.png)

#### 2a. Struktura projektu/programu:  
![struktura-projektu](struktura-projektu.png)

    